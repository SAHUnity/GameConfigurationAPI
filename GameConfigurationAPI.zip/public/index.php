<?php
// Simple redirect to admin
header('Location: admin/index.php');
exit;
